@echo off
chcp 65001 >nul
echo ========================================================
echo    LanShare for Windows - 설치 및 원클릭 실행기
echo ========================================================
echo.

REM 1. .NET 8 SDK Check
where dotnet >nul 2>nul
if %errorlevel% neq 0 (
    echo [알림] .NET SDK 가 감지되지 않았습니다.
    echo .NET 8 SDK 다운로드를 진행합니다...
    echo 브라우저에서 다운로드 페이지를 열거나, 아래 winget 명령어를 실행하세요:
    echo   winget install Microsoft.DotNet.SDK.8
    start https://dotnet.microsoft.com/download/dotnet/8.0
    pause
    exit /b
)

echo [*] .NET 8 환경 확인 완료.
echo [*] LanShare Windows 단일 실행 파일(.exe) 빌드 중...
echo.

cd /d "%~dp0src"
dotnet publish LanShare.Windows.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -o "%~dp0bin"

if %errorlevel% equ 0 (
    echo.
    echo ========================================================
    echo  [성공] LanShare.exe 가 성공적으로 빌드되었습니다!
    echo  위치: %~dp0bin\LanShare.exe
    echo ========================================================
    echo.
    echo LanShare 를 실행합니다...
    start "" "%~dp0bin\LanShare.exe"
) else (
    echo.
    echo [오류] 빌드 중 문제가 발생했습니다. 에러 메시지를 확인해주세요.
    pause
)
