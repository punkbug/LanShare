@echo off
cd /d "%~dp0"
if exist "bin\LanShare.exe" (
    start "" "bin\LanShare.exe"
) else (
    call Install-And-Run.bat
)
