LanShare for Windows
====================

1. 빠른 실행:
   - 'Quick-Start.bat' 또는 'Install-And-Run.bat'을 더블 클릭합니다.
   - 처음 실행 시 .NET 8 환경이 구성되고 'bin/LanShare.exe' 단일 실행 파일이 생성되어 자동 실행됩니다.

2. 방화벽 설정 안내:
   - Windows Defender 방화벽 경고 창이 나타나면 반드시 [개인 네트워크] 접근을 '허용'해주세요.
   - 기기 자동 검색(mDNS) 및 1:1 TCP 고속 전송을 위해 필수입니다.

3. 저장 경로:
   - 받은 파일은 사용자의 [다운로드\LanShare] 폴더에 안전하게 보관됩니다.
